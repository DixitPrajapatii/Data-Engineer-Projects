1. Show first name, last name, and gender of patients whose gender is 'M' 
SELECT  first_name, 
		last_name, 
		gender 
FROM patients WHERE gender='M';

2. Show first name and last name of patients who do not have allergies.
SELECT  first_name, 
		last_name 
FROM patients WHERE allergies IS NULL;

3. Show first name of patients that start with the letter 'C'
SELECT first_name FROM patients WHERE first_name LIKE 'C%';


4. Show first name and last name of patients that weight within the range of
100 to 120 (inclusive)
SELECT  first_name, 
		last_name 
FROM patients WHERE weight BETWEEN 100 and 120;

5. Update the patients table for the allergies column. If the patient's allergies is
null then replace it with 'NKA'
START TRANSACTION; -- OPTIONAL
UPDATE patients SET allergies='NKA' WHERE allergies IS NULL;
COMMIT ;   -- OPTIONAL

6. Show first name and last name concatenated into one column to show their
full name.
AS THE QUESTION IS NOT CLEAR WHAT EXACTLY REQUIRE LIKE FIRSTNAME,LASTNAME AND FULLNAME OR JUST FULLNAME SO ATTACHING TWO ANSWER. AND ALSO NOT MENTION HOW TO SEPARATE THEM SO ADDING DEFAULT SEPARATOR WHICH IS SPACE.
SELECT CONCAT(first_name,last_name) AS full_name FROM patients;
SELECT CONCAT_WS(' ',first_name,last_name) AS full_name FROM patients;
SELECT first_name, last_name, CONCAT(first_name,last_name) as full_name FROM patients;
SELECT first_name, last_name, CONCAT_WS(' ',first_name,last_name) as full_name FROM patients;


7. Show first name, last name, and the full province name of each patient.
SELECT P.first_name, 
	   P.last_name,
       PN.province_name
FROM patients AS P
INNER JOIN province_names AS PN ON PN.province_id=P.province_id; 

8. Show how many patients have a birth_date with 2010 as the birth year.
SELECT COUNT(*) FROM patients WHERE YEAR(birth_date)=2010;


9. Show the first_name, last_name, and height of the patient with the greatest
height.
SELECT first_name, last_name, height FROM patients WHERE height=(SELECT MAX(height) FROM patients);


10. Show all columns for patients who have one of the following patient_ids:
1,45,534,879,1000
SELECT * FROM patients WHERE patient_id IN  (1,45,534,879,1000);


11. Show the total number of admissions
SELECT COUNT(*) AS TOTAL_ADMISSION FROM admissions;


12. Show all the columns from admissions where the patient was admitted
and discharged on the same day.
SELECT * FROM admissions WHERE admission_date = discharge_date;


13. Show the total number of admissions for patient_id 579.
SELECT COUNT(*) AS TOTAL_ADMISSIONS FROM admissions WHERE patient_id=579;

14. Based on the cities that our patients live in, show unique cities that are in
province_id 'NS'?
SELECT DISTINCT city FROM patients WHERE province_id='NS';


15. Write a query to find the first_name, last name and birth date of patients
who have height more than 160 and weight more than 70

SELECT  first_name, 
		last_name, 
        birth_date
FROM patients WHERE height > 160 AND weight >70;



16. Show unique birth years from patients and order them by ascending.

SELECT DISTINCT YEAR(birth_date) BIRTH_YEAR
FROM patients
ORDER BY YEAR(birth_date) ASC;


17. Show unique first names from the patients table which only occurs once in
the list.
For example, if two or more people are named 'John' in the first_name column
then don't include their name in the output list. If only 1 person is named 'Leo'
then include them in the output. Tip: HAVING clause was added to SQL
because the WHERE keyword cannot be used with aggregate functions.

SELECT  DISTINCT first_name
FROM patients
GROUP BY first_name
having COUNT(first_name) =1 ;


18. Show patient_id and first_name from patients where their first_name starts
and ends with 's' and is at least 6 characters long.

SELECT  patient_id, 
		first_name
FROM patients
WHERE first_name LIKE 'S%S' AND length(first_name)>= 6;


19. Show patient_id, first_name, last_name from patients whose diagnosis is
'Dementia'. Primary diagnosis is stored in the admissions table.

SELECT   P.patient_id
		,P.first_name
        ,P.last_name
FROM patients AS P
INNER JOIN admissions AS A ON A.patient_id = P.patient_id
WHERE A.diagnosis ='Dementia';

20. Display every patient's first_name. Order the list by the length of each
name and then by alphabetically.

SELECT first_name
FROM patients
ORDER BY LENGTH(first_name) ASC, first_name ASC;


21. Show the total number of male patients and the total number of female
patients in the patients table. Display the two results in the same row.

SELECT 
	SUM(CASE WHEN gender='M' THEN 1 ELSE 0 END) AS MALE_PATIENT,
	SUM(CASE WHEN gender='F' THEN 1 ELSE 0 END) AS FEMALE_PATIENT
FROM patients;


22. Show the total number of male patients and the total number of female
patients in the patients table. Display the two results in the same row.

SELECT 
	SUM(CASE WHEN gender='M' THEN 1 ELSE 0 END) AS MALE_PATIENT,
	SUM(CASE WHEN gender='F' THEN 1 ELSE 0 END) AS FEMALE_PATIENT
FROM patients;


23. Show patient_id, diagnosis from admissions. Find patients admitted
multiple times for the same diagnosis.

SELECT  patient_id,
        diagnosis
FROM admissions
GROUP BY diagnosis, patient_id
HAVING COUNT(patient_id) > 1;


24. Show the city and the total number of patients in the city. Order from most
to least patients and then by city name ascending.

SELECT  city
		,COUNT(patient_id) TOTAL_PATIENTS
FROM patients
GROUP BY city
ORDER BY COUNT(patient_id) DESC, city ASC;


25. Show first name, last name and role of every person that is either patient
or doctor. The roles are either "Patient" or "Doctor"

SELECT  first_name
		,last_name
        ,'PATIENT' AS role
FROM patients
UNION ALL
SELECT   first_name
		,last_name
        ,'Doctor' as role
FROM doctors;


26. Show all allergies ordered by popularity. Remove NULL values from the
query.

SELECT allergies
FROM patients
WHERE allergies IS NOT NULL
GROUP BY allergies
ORDER BY COUNT(allergies) DESC;


27. Show all patient's first_name, last_name, and birth_date who were born in
the 1970s decade. Sort the list starting from the earliest birth_date.

SELECT   first_name
		,last_name
        ,birth_date
FROM patients
WHERE birth_date between '1970-01-01' AND '1970-12-31'
ORDER BY birth_date ASC;


28. We want to display each patient's full name in a single column. Their
last_name in all upper letters must appear first, then first_name in all lower
case letters. Separate the last_name and first_name with a comma. Order the
list by the first_name in descending order EX: SMITH,jane

SELECT concat_ws(',',UPPER(last_name),LOWER(first_name)) AS PATIENT_NAME
FROM patients
ORDER BY first_name DESC;


29. Show the province_id(s), sum of height; where the total sum of its patient's
height is greater than or equal to 7,000.

SELECT province_id
		,SUM(height) AS SUM_OF_HEIGHT
FROM patients
GROUP BY province_id
HAVING SUM(height) >=7000;

30. Show the difference between the largest weight and smallest weight for
patients with the last name 'Maroni'

SELECT MAX(weight) - MIN(weight)  AS WEIGHT_DIFFERENCE
FROM patients
WHERE last_name='Maroni';


31. Show all of the days of the month (1-31) and how many admission_dates
occurred on that day. Sort by the day with most admissions to least
admissions.

SELECT  DAY(admission_date) AS DAYS
        ,COUNT(PATIENT_ID) AS TOTAL_ADMISSION
FROM admissions
GROUP BY DAY(admission_date)
ORDER BY COUNT(patient_id) DESC;



32. Show all of the patients grouped into weight groups. Show the total
number of patients in each weight group. Order the list by the weight group
descending. e.g. if they weigh 100 to 109 they are placed in the 100 weight
group, 110-119 = 110 weight group, etc.

SELECT   FLOOR(weight / 10) * 10 AS weight_group
		,COUNT(*) AS total_patients
FROM patients
GROUP BY weight_group
ORDER BY weight_group DESC;


33. Show patient_id, weight, height, is Obese from the patients table. Display
isObese as a boolean 0 or 1. Obese is defined as weight(kg)/(height(m).
Weight is in units kg. Height is in units cm.

SELECT patient_id
		,weight
        ,height
        ,
	CASE 
        WHEN weight / ((height / 100) * (height / 100)) >= 30 THEN 1 
        ELSE 0 
    END AS isObese
FROM patients;


34. Show patient_id, first_name, last_name, and attending doctor's specialty.
Show only the patients who has a diagnosis as 'Epilepsy' and the doctor's first
name is 'Lisa'. Check patients, admissions, and doctors tables for required
information.

SELECT   A.patient_id
		,P.first_name
        ,P.last_name
        ,D.specialty
FROM admissions AS A
INNER JOIN doctors AS D ON D.doctor_id = A.attending_doctor_id
INNER JOIN patients AS P ON P.patient_id = A.patient_id
WHERE A.diagnosis = 'Epilepsy' AND D.first_name='Lisa';



35. All patients who have gone through admissions, can see their medical
documents on our site. Those patients are given a temporary password after
their first admission. Show the patient_id and temp_password.
The password must be the following, in order:
- patient_id
- the numerical length of patient's last_name
- year of patient's birth_date

SELECT   patient_id
		,concat(patient_id, length(last_name),YEAR(birth_date)) AS temp_password
FROM patients;